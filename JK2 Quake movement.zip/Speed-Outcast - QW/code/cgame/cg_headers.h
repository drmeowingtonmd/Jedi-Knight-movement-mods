// Precompiled header file for the client game

#include "cg_local.h"

//#include "CGEntity.h"
//#include "../game/SpawnSystem.h"
//#include "../game/EntitySystem.h"
//#include "../game/CScheduleSystem.h"

// end
