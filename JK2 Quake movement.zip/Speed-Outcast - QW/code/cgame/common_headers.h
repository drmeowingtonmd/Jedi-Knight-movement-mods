// this line must stay at top so the whole PCH thing works...
#include "cg_headers.h"

// I am a dummy header file that takes the place of the PCH files in SoF2.  This is done so that we can easily 
//	transport fx files amongst CHC, SoF2, and the effects editor...( If you are looking at this and have a better
//	idea, just let me know what the better solution is. )
// The files can't be shared directly through Source Safe since the projects reside in different SS databases.
//
// - JD

