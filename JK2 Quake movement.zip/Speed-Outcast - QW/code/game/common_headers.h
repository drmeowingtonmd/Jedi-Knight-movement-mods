#pragma once
#if !defined(COMMON_HEADERS_H_INC)
#define COMMON_HEADERS_H_INC

#if !defined(__Q_SHARED_H)
	#include "../game/q_shared.h"
#endif

//#if !defined(Q_SHAREDBASIC_H_INC)
//	#include "../game/q_sharedbasic.h"			// fileHandle_t
//#endif

//#if !defined(Q_MATH_H_INC)
//	#include "../game/q_math.h"
//#endif

#endif // COMMON_HEADERS_H_INC
