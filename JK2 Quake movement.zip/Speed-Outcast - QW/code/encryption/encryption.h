//Pakinator Main Header

//define this to enable all pak files encryption requirements
#ifdef FINAL_BUILD
//#define _ENCRYPTION_
#endif