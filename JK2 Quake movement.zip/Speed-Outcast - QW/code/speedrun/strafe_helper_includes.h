#ifndef STRAFE_HELPER_INCLUDES_H
#define STRAFE_HELPER_INCLUDES_H

#include <math.h>
#include <stdio.h>

#endif // STRAFE_HELPER_INCLUDES_H
