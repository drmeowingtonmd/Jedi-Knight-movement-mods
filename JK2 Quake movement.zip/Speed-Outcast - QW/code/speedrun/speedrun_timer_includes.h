#pragma once

void SpeedrunTimerPrint(bool printNotify,
                        const char *levelTimeString,
                        const char *totalTimeString);
int SpeedrunTimerGetSystemMilliseconds();
