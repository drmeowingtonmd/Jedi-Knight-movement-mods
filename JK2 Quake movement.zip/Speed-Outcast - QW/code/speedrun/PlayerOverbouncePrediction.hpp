#pragma once

#include "overbounce_prediction/OverbouncePrediction.hpp"
#include <memory>


extern std::unique_ptr<OverbouncePrediction> playerOverbouncePredictor;
