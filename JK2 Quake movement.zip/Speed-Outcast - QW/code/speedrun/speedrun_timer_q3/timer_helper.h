#pragma once
#include <string>

std::string GetTimeStringFromMilliseconds(int milliseconds, int accuracy);
