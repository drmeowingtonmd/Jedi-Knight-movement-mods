Overbounce Prediction
=====================

Code for predicting the probability of an overbounce in games that use the
movement code of the id Tech 3 engine. This was written for the three
**id Tech 3** games by Raven Software, *Star Trek: Voyager - Elite Force*,
*Star Wars Jedi Knight II: Jedi Outcast* and
*Star Wars Jedi Knight: Jedi Academy*, but it should work fine for other
**id Tech 3** games too.

What is an overbounce?
----------------------
TODO

How is the prediction made?
---------------------------
TODO
